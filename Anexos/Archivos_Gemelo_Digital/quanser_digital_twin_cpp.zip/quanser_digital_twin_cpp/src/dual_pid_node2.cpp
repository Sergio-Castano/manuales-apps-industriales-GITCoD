#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float64.hpp"
#include <sched.h>
#include <sys/mman.h>
#include <unistd.h>
#include <chrono>
#include <fstream>
#include <vector>
#include <iostream>
#include <algorithm>
#include <cmath>

class PIDControllerNode : public rclcpp::Node
{
public:
    PIDControllerNode() : Node("pid_node")
    {
        // ============================
        //  CONFIGURACIÓN RT
        // ============================
        set_priority_and_affinity();
        mlockall(MCL_CURRENT | MCL_FUTURE);

        // ============================
        //  PARÁMETROS
        // ============================
        this->declare_parameter("dt", 0.01);
        dt_ = this->get_parameter("dt").as_double();
        if (dt_ <= 0.0) dt_ = 0.01;

        declare_and_get("kp", kp_, 0.1);
        declare_and_get("ki", ki_, 0.1);
        declare_and_get("kd", kd_, 0.00004);

        reset_states();

        // ============================
        //  SUBSCRIPTORES
        // ============================
        sub_ref_ = create_subscription<std_msgs::msg::Float64>(
            "/ref_voltage_sim", 10,
            [this](const std_msgs::msg::Float64::SharedPtr msg){
                ref_ = msg->data;
            });

        sub_meas_ = create_subscription<std_msgs::msg::Float64>(
            "/motor_speed_sim_disc", 10,
            [this](const std_msgs::msg::Float64::SharedPtr msg){
                meas_ = msg->data;
            });

        // ============================
        //  PUBLICADOR
        // ============================
        pub_u_ = create_publisher<std_msgs::msg::Float64>("/cmd_voltage_disc", 10);

        // ============================
        //  TIMER PRINCIPAL
        // ============================
        timer_ = create_wall_timer(
            std::chrono::duration<double>(dt_),
            std::bind(&PIDControllerNode::update, this));

        RCLCPP_INFO(this->get_logger(),
            "PID DISC iniciado con dt=%.6f  prioridad=85  CPU=3", dt_);
    }

    ~PIDControllerNode()
    {
        save_sample_times();
    }

private:
    // ============================
    //  VARIABLES PID
    // ============================
    double dt_;
    double kp_, ki_, kd_;
    double ref_, meas_, integral_, prev_err_, prev_deriv_;

    // ============================
    //  ROS2
    // ============================
    rclcpp::Subscription<std_msgs::msg::Float64>::SharedPtr sub_ref_, sub_meas_;
    rclcpp::Publisher<std_msgs::msg::Float64>::SharedPtr pub_u_;
    rclcpp::TimerBase::SharedPtr timer_;

    // ============================
    //  MEDICIÓN DEL SAMPLE TIME
    // ============================
    std::vector<double> sample_times_;
    std::chrono::high_resolution_clock::time_point last_cycle_time_;

    // ============================
    //  UTILIDADES
    // ============================
    void declare_and_get(const std::string &name, double &var, double def)
    {
        this->declare_parameter(name, def);
        var = this->get_parameter(name).as_double();
    }

    void reset_states()
    {
        ref_ = meas_ = integral_ = prev_err_ = prev_deriv_ = 0.0;
        last_cycle_time_ = std::chrono::high_resolution_clock::time_point{};
    }

    // ============================
    //  LOOP PRINCIPAL PID
    // ============================
    void update()
    {
        // -------- Medición del sample time --------
        auto now = std::chrono::high_resolution_clock::now();

        if (last_cycle_time_.time_since_epoch().count() > 0)
        {
            std::chrono::duration<double> T = now - last_cycle_time_;
            double ms = T.count() * 1000.0;
            sample_times_.push_back(ms);
        }

        last_cycle_time_ = now;

        // -------- Actualizar parámetros en runtime --------
        kp_ = this->get_parameter("kp").as_double();
        ki_ = this->get_parameter("ki").as_double();
        kd_ = this->get_parameter("kd").as_double();

        // -------- PID --------
        double error = ref_ - meas_;
        integral_ += error * dt_;

        double deriv = (error - prev_err_) / dt_;
        deriv = 0.9 * prev_deriv_ + 0.1 * deriv;  // Filtro
        prev_deriv_ = deriv;
        prev_err_   = error;

        double u = kp_ * error + ki_ * integral_ + kd_ * deriv;
        u = std::clamp(u, -15.0, 15.0);

        // -------- Publicar --------
        std_msgs::msg::Float64 msg;
        msg.data = u;
        pub_u_->publish(msg);
    }

    // ============================
    //  GUARDAR SAMPLE TIMES
    // ============================
    void save_sample_times()
    {
        std::ofstream file("pid2_sample_times.txt");
        for (double s : sample_times_)
            file << s << "\n";

        file.close();
        std::cout << "[PID2] tiempos de muestreo guardados en pid2_sample_times.txt\n";
    }

    // ============================
    //  PRIORIDAD Y AFINIDAD CPU
    // ============================
    void set_priority_and_affinity()
    {
        struct sched_param param;
        param.sched_priority = 85;

        if (sched_setscheduler(0, SCHED_FIFO, &param) == -1)
            perror("sched_setscheduler error");

        cpu_set_t cpuset;
        CPU_ZERO(&cpuset);
        CPU_SET(3, &cpuset);

        if (sched_setaffinity(0, sizeof(cpuset), &cpuset) == -1)
            perror("sched_setaffinity error");
    }
};

int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<PIDControllerNode>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
