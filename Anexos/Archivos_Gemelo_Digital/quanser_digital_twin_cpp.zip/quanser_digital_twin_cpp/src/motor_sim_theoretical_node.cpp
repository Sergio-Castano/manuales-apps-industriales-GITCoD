#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float64.hpp"
#include <Eigen/Dense>
#include <sched.h>
#include <sys/mman.h>
#include <unistd.h>
#include <chrono>
#include <fstream>
#include <vector>
#include <iostream>

class MotorSimTustin : public rclcpp::Node
{
public:
    MotorSimTustin() : Node("motor_sim_tustin")
    {
        // Asignar la prioridad y la afinidad de CPU
        set_priority_and_affinity();

        declare_parameter("dt", 0.001);
        dt_ = get_parameter("dt").as_double();

        // Constantes físicas
        J_ = 1.16e-6;
        b_ = 6.82e-6;
        Kt_ = 0.0069;
        Ke_ = 0.0069;
        R_ = 10.6;
        L_ = 0.00082;

        // Matrices continuas
        Ac_ << -R_/L_, -Ke_/L_,
               Kt_/J_, -b_/J_;

        Bc_ << 1.0/L_,
               0.0;

        Cc_ << 0, 1; // Salida = omega

        // Discretización Tustin
        Eigen::Matrix2d I = Eigen::Matrix2d::Identity();
        Eigen::Matrix2d M1 = (I - 0.5 * dt_ * Ac_);
        Eigen::Matrix2d M2 = (I + 0.5 * dt_ * Ac_);

        Ad_ = M1.inverse() * M2;
        Bd_ = M1.inverse() * (dt_ * Bc_);

        x_.setZero();
        V_ = 0.0;

        // Bloquear toda la memoria del proceso
        mlockall(MCL_CURRENT | MCL_FUTURE);

        // Suscripción
        sub_ = create_subscription<std_msgs::msg::Float64>(
            "/cmd_voltage", 10, std::bind(&MotorSimTustin::voltage_callback, this, std::placeholders::_1));

        // Publicador
        pub_speed_ = create_publisher<std_msgs::msg::Float64>("/motor_speed", 10);

        // Timer
        timer_ = create_wall_timer(
            std::chrono::duration<double>(dt_),
            std::bind(&MotorSimTustin::update, this));

        RCLCPP_INFO(get_logger(), "Motor Tustin iniciado dt=%.6f", dt_);
    }

    // Guardar tiempos de ejecución en el destructor
    ~MotorSimTustin()
    {
        save_execution_times();
    }

    // Función para guardar los tiempos de ejecución
    void save_execution_times()
    {
        std::ofstream file("execution_times.txt");
        for (const auto& time : execution_times_) {
            file << time << "\n";
        }
        file.close();
        std::cout << "Tiempos de ejecución guardados en 'execution_times.txt'" << std::endl;
    }

private:
    double dt_;
    double J_, b_, Kt_, Ke_, R_, L_;
    double V_;

    Eigen::Matrix2d Ac_, Ad_;
    Eigen::Vector2d x_, Bd_, Bc_;
    Eigen::RowVector2d Cc_;

    rclcpp::Subscription<std_msgs::msg::Float64>::SharedPtr sub_;
    rclcpp::Publisher<std_msgs::msg::Float64>::SharedPtr pub_speed_;
    rclcpp::TimerBase::SharedPtr timer_;

    std::vector<double> execution_times_;  // Arreglo para guardar los tiempos de ejecución

    // Función para recibir el voltaje
    void voltage_callback(const std_msgs::msg::Float64::SharedPtr msg)
    {
        V_ = std::clamp(msg->data, -12.0, 12.0);
    }

    void update()
    {
        // Medir el tiempo de inicio
        auto start = std::chrono::high_resolution_clock::now();

        // Dinámica discreta
        x_ = Ad_ * x_ + Bd_ * V_;

        std_msgs::msg::Float64 msg;
        msg.data = Cc_ * x_;  // omega
        pub_speed_->publish(msg);

        // Medir el tiempo de fin y calcular el tiempo de ejecución
        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> duration = end - start;

        // Guardar el tiempo de ejecución en el arreglo
        execution_times_.push_back(duration.count());
    }

    // Asignación de prioridad de ejecución y afinidad a core 3
    void set_priority_and_affinity()
    {
        // Establecer la prioridad (70)
        struct sched_param sched_param;
        sched_param.sched_priority = 70;
        if (sched_setscheduler(0, SCHED_FIFO, &sched_param) == -1) {
            perror("Failed to set scheduler priority");
        }

        // Asignar el proceso al core 3 (CPU 3)
        cpu_set_t cpuset;
        CPU_ZERO(&cpuset);
        CPU_SET(2, &cpuset);  // Asegura que el proceso se ejecute en el core 3

        if (sched_setaffinity(0, sizeof(cpu_set_t), &cpuset) == -1) {
            perror("Failed to set CPU affinity");
        }
    }
};

int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);

    auto node = std::make_shared<MotorSimTustin>();

    rclcpp::spin(node);

    rclcpp::shutdown();

    return 0;
}
