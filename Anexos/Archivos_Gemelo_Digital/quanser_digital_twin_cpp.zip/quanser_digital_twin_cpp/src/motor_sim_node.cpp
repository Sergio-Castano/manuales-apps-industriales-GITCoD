#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float64.hpp"
#include <sched.h>
#include <sys/mman.h>
#include <unistd.h>
#include <chrono>
#include <fstream>
#include <vector>
#include <iostream>
#include <algorithm>

class MotorSimNode : public rclcpp::Node
{
public:
    MotorSimNode() : Node("motor_sim_node")
    {
        // ==============================
        // Prioridad en tiempo real y CPU
        // ==============================
        set_priority_and_affinity();

        // Bloquear memoria (evitar page faults)
        mlockall(MCL_CURRENT | MCL_FUTURE);

        // ==============================
        // Parámetros
        // ==============================
        this->declare_parameter("dt", 0.01);
        dt_ = this->get_parameter("dt").as_double();
        if (dt_ <= 0.0) dt_ = 0.01;

        // ==============================
        // Suscripción / Publicación
        // ==============================
        sub_ = create_subscription<std_msgs::msg::Float64>(
            "/cmd_voltage_disc", 10,
            std::bind(&MotorSimNode::cmd_callback, this, std::placeholders::_1));

        pub_ = create_publisher<std_msgs::msg::Float64>("/motor_speed_sim_disc", 10);

        // ==============================
        // Timer
        // ==============================
        timer_ = create_wall_timer(
            std::chrono::duration<double>(dt_),
            std::bind(&MotorSimNode::update, this));

        // ==============================
        // Variables del modelo
        // ==============================
        u_ = 0.0;
        y_ = {0.0, 0.0};
        u_hist_ = {0.0, 0.0};

        // Coeficientes ZOH de tu planta
        a1_ = -1.003;
        a2_ = 0.06946;
        b0_ = 2.673;
        b1_ = 1.142;

        RCLCPP_INFO(get_logger(), "MotorSim DISC iniciado dt=%.6f", dt_);
    }

    ~MotorSimNode()
    {
        save_execution_times();
    }

private:
    double dt_;
    double u_;
    std::vector<double> y_, u_hist_;

    double a1_, a2_, b0_, b1_;
    rclcpp::Subscription<std_msgs::msg::Float64>::SharedPtr sub_;
    rclcpp::Publisher<std_msgs::msg::Float64>::SharedPtr pub_;
    rclcpp::TimerBase::SharedPtr timer_;

    // Para guardar tiempos de ejecución
    std::vector<double> execution_times_;

    void cmd_callback(const std_msgs::msg::Float64::SharedPtr msg)
    {
        u_ = msg->data;
    }

    void update()
    {
        // ==============================
        // Tiempo inicio del ciclo
        // ==============================
        auto start = std::chrono::high_resolution_clock::now();

        // ==============================
        // Dinámica discreta EXACTA como tu código
        // ==============================
        double y_new =
            -a1_ * y_[0]
            - a2_ * y_[1]
            + b0_ * u_
            + b1_ * u_hist_[0];

        // desplazamientos
        y_[1] = y_[0];
        y_[0] = y_new;

        u_hist_[1] = u_hist_[0];
        u_hist_[0] = u_;

        // publicar salida
        std_msgs::msg::Float64 msg;
        msg.data = y_new;
        pub_->publish(msg);

        // ==============================
        // Tiempo fin del ciclo
        // ==============================
        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> duration = end - start;

        // guardar tiempo de ejecución EN SEGUNDOS
        execution_times_.push_back(duration.count());
    }

    // ==============================
    // Guardar datos en archivo
    // ==============================
    void save_execution_times()
    {
        std::ofstream file("motor_disc_exec_times.txt");
        for (double t : execution_times_)
            file << t << "\n";

        file.close();
        std::cout << "[Motor DISC] tiempos guardados en motor_disc_exec_times.txt\n";
    }

    // ==============================
    // Prioridad y afinidad CPU
    // ==============================
    void set_priority_and_affinity()
    {
        struct sched_param param;
        param.sched_priority = 75;

        if (sched_setscheduler(0, SCHED_FIFO, &param) == -1)
            perror("sched_setscheduler error");

        cpu_set_t cpuset;
        CPU_ZERO(&cpuset);
        CPU_SET(3, &cpuset);

        if (sched_setaffinity(0, sizeof(cpuset), &cpuset) == -1)
            perror("sched_setaffinity error");
    }
};

int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);

    auto node = std::make_shared<MotorSimNode>();
    rclcpp::spin(node);

    rclcpp::shutdown();
    return 0;
}
