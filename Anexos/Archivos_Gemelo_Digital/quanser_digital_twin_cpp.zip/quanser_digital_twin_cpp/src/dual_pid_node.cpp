#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float64.hpp"
#include <algorithm>
#include <sched.h>
#include <sys/mman.h>
#include <unistd.h>
#include <chrono>
#include <fstream>
#include <vector>
#include <iostream>

class PIDTustin : public rclcpp::Node
{
public:
    PIDTustin() : Node("pid_tustin")
    {
        // Asignar la prioridad y la afinidad de CPU
        set_priority_and_affinity();

        declare_parameter("dt", 0.001);
        dt_ = get_parameter("dt").as_double();

        declare_parameter("kp", 0.1);    // Mantén Kp para una respuesta controlada
        declare_parameter("ki", 0.1);     // Ki bajo para evitar acumulación excesiva
        declare_parameter("kd", 0.0005);  // Aumenta ligeramente Kd para suavizar

        kp_ = get_parameter("kp").as_double();
        ki_ = get_parameter("ki").as_double();
        kd_ = get_parameter("kd").as_double();

        ref_ = 0.0;
        meas_ = 0.0;
        integral_ = 0.0;
        prev_error_ = 0.0;
        prev_deriv_ = 0.0;  // Inicializamos prev_deriv_

        // Bloquear toda la memoria del proceso
        mlockall(MCL_CURRENT | MCL_FUTURE);

        // Usamos métodos explícitos para los callbacks
        sub_ref_ = create_subscription<std_msgs::msg::Float64>(
            "/ref_speed", 10, std::bind(&PIDTustin::ref_callback, this, std::placeholders::_1));

        sub_meas_ = create_subscription<std_msgs::msg::Float64>(
            "/motor_speed", 10, std::bind(&PIDTustin::meas_callback, this, std::placeholders::_1));

        pub_cmd_ = create_publisher<std_msgs::msg::Float64>("/cmd_voltage", 10);

        timer_ = create_wall_timer(
            std::chrono::duration<double>(dt_),
            std::bind(&PIDTustin::update, this));

        RCLCPP_INFO(get_logger(), "PID Tustin iniciado dt=%.6f", dt_);
    }

    void save_execution_times()
    {
        std::ofstream file("pid_sample_times.txt");
        for (const auto& time : sample_times_) {
            file << time << "\n";
        }
        file.close();
        std::cout << "Tiempos de muestreo guardados en 'pid_sample_times.txt'" << std::endl;
    }

private:
    double dt_;
    double kp_, ki_, kd_;

    double ref_, meas_, integral_, prev_error_;
    double prev_deriv_;  // Agregado para suavizar la derivada

    rclcpp::Subscription<std_msgs::msg::Float64>::SharedPtr sub_ref_, sub_meas_;
    rclcpp::Publisher<std_msgs::msg::Float64>::SharedPtr pub_cmd_;
    rclcpp::TimerBase::SharedPtr timer_;

    std::vector<double> sample_times_;  // Arreglo para guardar los tiempos de muestreo

    // Variables para medir el tiempo entre ciclos
    std::chrono::high_resolution_clock::time_point last_cycle_time_;

    // Función para recibir la referencia
    void ref_callback(const std_msgs::msg::Float64::SharedPtr msg)
    {
        ref_ = msg->data;
    }

    // Función para recibir la medición
    void meas_callback(const std_msgs::msg::Float64::SharedPtr msg)
    {
        meas_ = msg->data;
    }

    void update()
    {
        // Medir el tiempo de inicio para el muestreo
        auto start = std::chrono::high_resolution_clock::now();

        if (last_cycle_time_.time_since_epoch().count() > 0) {
            // Calcular el tiempo de muestreo entre el ciclo actual y el anterior
            std::chrono::duration<double> sample_period = start - last_cycle_time_;
            double sample_period_ms = sample_period.count() * 1000.0;  // Convertir a milisegundos
            sample_times_.push_back(sample_period_ms);  // Guardar el período de muestreo en ms
        }

        // Actualizar el tiempo del ciclo actual para el siguiente ciclo
        last_cycle_time_ = start;

        kp_ = get_parameter("kp").as_double();
        ki_ = get_parameter("ki").as_double();
        kd_ = get_parameter("kd").as_double();

        double error = ref_ - meas_;
        integral_ += error * dt_;  // Acumulación del error

        // Derivada con suavizado (filtro)
        double deriv = (error - prev_error_) / dt_;
        deriv = 0.9 * prev_deriv_ + 0.1 * deriv;  // Filtro de derivada
        prev_deriv_ = deriv;

        prev_error_ = error;

        // Calcular salida (PID)
        double u = kp_ * error + ki_ * integral_ + kd_ * deriv;

        // Publicar el valor de salida
        std_msgs::msg::Float64 msg;
        msg.data = u;
        pub_cmd_->publish(msg);
    }

    // Asignación de prioridad de ejecución y afinidad a core 3
    void set_priority_and_affinity()
    {
        // Establecer la prioridad (75)
        struct sched_param sched_param;
        sched_param.sched_priority = 90;
        if (sched_setscheduler(0, SCHED_FIFO, &sched_param) == -1) {
            perror("Failed to set scheduler priority");
        }

        // Asignar el proceso al core 3 (CPU 3)
        cpu_set_t cpuset;
        CPU_ZERO(&cpuset);
        CPU_SET(3, &cpuset);  // Asegura que el proceso se ejecute en el core 3

        if (sched_setaffinity(0, sizeof(cpu_set_t), &cpuset) == -1) {
            perror("Failed to set CPU affinity");
        }
    }
};

int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);

    auto node = std::make_shared<PIDTustin>();

    // Usar el manejador por defecto de ROS 2 para que el nodo termine correctamente
    rclcpp::spin(node);

    // Guardar los tiempos de muestreo antes de realizar el shutdown
    node->save_execution_times();

    rclcpp::shutdown();

    return 0;
}
